# PORK CODE CATHEDRAL Ω — BUILD-001

A local-first Android prototype using Kotlin, Compose, Room/SQLite. No Internet permission, account, or AI API key. All state stays in Android app-private SQLite storage unless you explicitly export it.

## Build in Android Studio

1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open the `PorkCodeCathedral` folder as a project (not the ZIP itself).
3. Allow Gradle sync; the first build downloads dependencies and requires Internet.
4. Select an Android device/emulator (Android 8.0+).
5. Run the `app` configuration, or choose **Build > Build APK(s)**.
6. APK is typically at `app/build/outputs/apk/debug/app-debug.apk` after successful build.

If Gradle wrapper files are missing, Android Studio can use an installed Gradle 8.9 distribution. Generate wrapper via `gradle wrapper --gradle-version 8.9` in the project directory if Gradle is installed. The project deliberately contains no generated Gradle wrapper JAR.

## Use

- **Tree:** enter root, create N000, inspect nodes and branches, fork and compare.
- **Mutate:** choose branch, enter full replacement payload, propose, validate, manually approve and accept.
- **Memory:** add user-stated local notes.
- **Backup:** use Android's system document picker to export/import a full JSON checkpoint.

## Integrity and limitations

- Root and accepted node payloads are never updated by UI operations.
- Parent links and SHA-256 are checked on checkpoint import, and a cycle check rejects invalid ancestry.
- Checkpoint import is an atomic database replacement. Keep an export before importing.
- This prototype handles a single local project and does not implement network APIs, model integration, semantic AI review, merge UI, migrations, encryption, or automated RE-NEXT.
- The usefulness gate only checks that content changed; the human review checkbox is mandatory.
- Exported JSON is readable and not encrypted. Store it securely.
- No build or emulator run was possible in the creation environment; compilation and device behavior are **unverified**.


## BUILD-002 integrity hardening (RE-NEXT)

- Candidate review approval is scoped per candidate card (no cross-candidate approval leak).
- Accepted node IDs use the highest existing numeric ID, rather than row count.
- Checkpoint import rejects missing/invalid N000 roots, parentless descendants, duplicate candidate/memory/event IDs, and accepted candidates without a corresponding descendant.
- Checkpoint restoration remains atomic within a Room transaction.
- Validation of semantic scope and usefulness still requires explicit human review; mechanical checks do **not** prove them.
- The root editor is a starter placeholder; paste your exact canonical ROOT_TEXT before initialization.

### Known gaps

The current checkpoint is JSON, not ZIP. Root payloads are immutable at the application service level, not protected from direct SQLite edits. The import schema does not preserve candidate creation timestamps or a separate verification evidence ledger. No compiled APK, Gradle wrapper, or SDK-based test results are included. The build is unverified because Gradle and Android SDK are not available in the build environment.

## BUILD-003 — validation and test hardening

- Added pure Kotlin `LineageRules.kt`, with JVM unit tests for IDs, branch names, dimensions and echo detection.
- Candidate mutation rejects oversized payloads and invalid dimensions before database insertion.
- Checkpoint export takes a consistent snapshot inside a Room transaction.
- Import rejects invalid node identifiers, parents numbered after their children, missing `main`, invalid branch names, malformed candidate dimensions, and mismatched merge-parent evidence.
- Retained Room schema version 1 and all BUILD-002 entities/fields; no destructive migration.
- Build environment lacked Android SDK, Gradle executable and Gradle wrapper JAR. Android compilation, Room processor generation and instrumented tests remain unverified.
- Local Kotlin compiler smoke test can be run with `bash scripts/smoke-test.sh`; it checks only pure Kotlin lineage rules, not Android build behavior.
