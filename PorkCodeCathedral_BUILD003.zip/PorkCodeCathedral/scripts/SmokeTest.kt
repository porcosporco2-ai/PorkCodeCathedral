import com.porkcode.cathedral.LineageRules

fun main() {
    check(LineageRules.nextNodeId(listOf("N000", "N002", "N011")) == "N012")
    check(LineageRules.nextNodeId(emptyList()) == "N000")
    check(!LineageRules.validNodeId("N0A"))
    check(LineageRules.validNodeId("N000"))
    check(!LineageRules.validBranchName("spaces no"))
    check(LineageRules.validBranchName("girth_engine"))
    check(!LineageRules.validDimension("  "))
    check(!LineageRules.changed("same", "same"))
    check(LineageRules.changed("old", "new"))
    println("PASS: 9 pure-Kotlin lineage assertions")
}
