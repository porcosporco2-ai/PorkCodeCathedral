#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc app/src/main/java/com/porkcode/cathedral/LineageRules.kt scripts/SmokeTest.kt -include-runtime -d "$TMP/smoke.jar"
java -jar "$TMP/smoke.jar"
