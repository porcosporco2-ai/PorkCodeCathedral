package com.porkcode.cathedral

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CathedralVm(val engine:CathedralEngine,val db:CathedralDatabase):ViewModel() {
    val nodes=db.dao().nodes().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val branches=db.dao().branches().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val candidates=db.dao().candidates().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val memories=db.dao().memories().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    var message by mutableStateOf("Offline Cathedral ready")
    fun run(block:suspend ()->Unit) { viewModelScope.launch { try { block() } catch(e:Exception) { message="Error: ${e.message}" } } }
}

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        val db=Room.databaseBuilder(applicationContext,CathedralDatabase::class.java,"cathedral.db").build()
        val engine=CathedralEngine(db)
        setContent {
            val vm:CathedralVm=viewModel(factory=object:ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST") override fun <T:ViewModel> create(modelClass:Class<T>):T = CathedralVm(engine,db) as T
            })
            CathedralScreen(vm, { text->contentResolver.openOutputStream(text.first)?.use { it.write(text.second.toByteArray()) } }, { uri->contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Could not read checkpoint") })
        }
    }
}

@Composable
fun CathedralScreen(vm:CathedralVm,unusedWriter:(Pair<android.net.Uri,String>)->Unit,reader:(android.net.Uri)->String) {
    val nodes by vm.nodes.collectAsState(); val branches by vm.branches.collectAsState()
    val candidates by vm.candidates.collectAsState(); val memories by vm.memories.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var root by remember { mutableStateOf("PORK_MEFORK // MONKEY BOY\nROOT CANON") }
    var branch by remember { mutableStateOf("main") };var forkName by remember { mutableStateOf("") }
    var dimension by remember { mutableStateOf("creative_revision") };var payload by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") };var comparison by remember { mutableStateOf("") }
    var compareA by remember { mutableStateOf("N000") };var compareB by remember { mutableStateOf("N000") }
    // Review consent belongs to each individual candidate, never shared between cards.
    var pendingExport by remember { mutableStateOf("") }
    val exporter=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if(uri!=null) vm.run { unusedWriter(uri to pendingExport);vm.message="Checkpoint exported" }
    }
    val importer=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) vm.run { vm.engine.importJson(reader(uri));vm.message="Checkpoint imported" }
    }
    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            Text("PORK CODE CATHEDRAL Ω",style=MaterialTheme.typography.titleLarge)
            Text(vm.message,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)
            ScrollableTabRow(selectedTabIndex=tab) { listOf("Tree","Mutate","Memory","Backup").forEachIndexed { i,t -> Tab(selected=tab==i,onClick={tab=i},text={Text(t)}) } }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxSize()) {
                when(tab) {
                    0 -> {
                        if(nodes.isEmpty()) item { OutlinedTextField(root,{root=it},label={Text("Original root text")},modifier=Modifier.fillMaxWidth());Button(onClick={vm.run { vm.engine.initialize(root);vm.message="Root N000 created" }}) { Text("Create immutable root") } }
                        items(nodes) { n -> ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text("${n.id} ← ${n.parentId ?: "ROOT"}${n.secondParentId?.let { " + $it" } ?: ""}");Text(n.payload.take(300));Text("SHA256 ${n.hash.take(16)}…",style=MaterialTheme.typography.labelSmall) } } }
                        item { Text("Branches: ${branches.joinToString { "${it.name}→${it.headId}" }}") }
                        if(nodes.isNotEmpty()) item { OutlinedTextField(forkName,{forkName=it},label={Text("New branch name")});Button(onClick={vm.run { vm.engine.fork(branches.firstOrNull()?.headId ?: "N000",forkName);vm.message="Fork created" }}) { Text("Fork current main head") } }
                        if(nodes.size>1) item { OutlinedTextField(compareA,{compareA=it},label={Text("Compare first node ID")});OutlinedTextField(compareB,{compareB=it},label={Text("Compare second node ID")});Button(onClick={vm.run { comparison=vm.engine.compare(compareA,compareB) }}) { Text("Compare") };Text(comparison) }
                    }
                    1 -> {
                        item { Text("Candidate mutations are not accepted until you approve review.") }
                        item { OutlinedTextField(branch,{branch=it},label={Text("Branch")});OutlinedTextField(dimension,{dimension=it},label={Text("Mutation dimension")});OutlinedTextField(payload,{payload=it},label={Text("Complete new payload")},modifier=Modifier.fillMaxWidth(),minLines=4);Button(onClick={vm.run { val id=vm.engine.mutate(branch,dimension,payload);vm.message="Candidate ${id.take(8)} created" }}) { Text("Propose mutation") } }
                        items(candidates) { c -> ElevatedCard { Column(Modifier.padding(12.dp)) { Text("${c.id.take(8)} • ${c.status} • ${c.branch}");Text("${c.dimension}: ${c.payload.take(120)}");if(c.status=="DRAFT") { var review by remember(c.id) { mutableStateOf(false) }; var result by remember(c.id) { mutableStateOf("") };Button(onClick={vm.run { result=vm.engine.validate(c.id).toString() }}) { Text("Validate") };Text(result);Row { Checkbox(review,onCheckedChange={review=it});Text("I reviewed this candidate") };Button(enabled=review,onClick={vm.run { val id=vm.engine.accept(c.id,review);vm.message="Accepted $id";review=false }}) { Text("Accept revision") } } } } }
                    }
                    2 -> {
                        item { OutlinedTextField(note,{note=it},label={Text("Memory note")},modifier=Modifier.fillMaxWidth());Button(onClick={vm.run { vm.engine.remember(note,"USER_STATED");note="" }}) { Text("Save locally") } }
                        items(memories) { m -> Text("${m.status}: ${m.content}") }
                    }
                    else -> {
                        item { Text("Export and import all local lineage data as JSON. Import replaces current project after validation.") }
                        item { Button(onClick={vm.run { pendingExport=vm.engine.exportJson();exporter.launch("pork-cathedral-checkpoint.json") }}) { Text("Export checkpoint") } }
                        item { Button(onClick={importer.launch(arrayOf("application/json","text/plain"))}) { Text("Import checkpoint") } }
                    }
                }
            }
        }
    }
}
