package com.porkcode.cathedral

import androidx.room.withTransaction
import java.security.MessageDigest
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

fun sha256(value:String):String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
fun newId() = UUID.randomUUID().toString()
data class Check(val scope:Boolean, val requirements:Boolean, val lineage:Boolean, val usefulness:Boolean, val explanation:String) {
    val pass get() = scope && requirements && lineage && usefulness
}

class CathedralEngine(private val db:CathedralDatabase) {
    private val dao = db.dao()
    suspend fun initialize(root:String) = db.withTransaction {
        if (dao.allNodes().isEmpty()) {
            require(root.isNotBlank())
            dao.insertNode(Node("N000",null,null,root,sha256(root),System.currentTimeMillis()))
            dao.insertBranch(Branch("main","N000"))
            event("ROOT_CREATED","N000")
        }
    }
    private suspend fun event(kind:String,detail:String) { dao.insertEvent(AuditEvent(newId(),kind,detail,System.currentTimeMillis())) }
    suspend fun fork(from:String,name:String) = db.withTransaction {
        require(LineageRules.validBranchName(name)) { "Invalid branch name" }
        require(dao.node(from)!=null) { "Unknown parent" }
        dao.insertBranch(Branch(name,from)); event("FORK","$name from $from")
    }
    suspend fun mutate(branch:String,dimension:String,payload:String,secondParent:String?=null):String = db.withTransaction {
        val head=dao.branch(branch) ?: error("Unknown branch")
        require(LineageRules.validDimension(dimension) && payload.isNotBlank() && payload.length<=500_000)
        if (secondParent!=null) require(dao.node(secondParent)!=null && secondParent!=head.headId)
        val id=newId(); dao.insertCandidate(Candidate(id,branch,head.headId,secondParent,dimension,payload));event("CANDIDATE_CREATED",id);id
    }
    suspend fun validate(id:String):Check {
        val c=dao.candidate(id) ?: error("Unknown candidate")
        val base=dao.node(c.baseId)
        val branch=dao.branch(c.branch)
        val scope=LineageRules.validDimension(c.dimension) && c.payload.isNotBlank() // Semantic scope requires review
        val requirements=c.payload.isNotBlank() && c.payload.length<=500_000 && sha256(c.payload).length==64
        val lineage=base!=null && branch?.headId==c.baseId && (c.secondParentId==null || (dao.node(c.secondParentId)!=null && c.secondParentId!=c.baseId))
        val usefulness=base!=null && LineageRules.changed(base.payload,c.payload) // Difference, not semantic usefulness
        return Check(scope,requirements,lineage,usefulness, "Mechanical checks only; semantic usefulness and factual accuracy require human review")
    }
    suspend fun accept(id:String,reviewApproved:Boolean):String = db.withTransaction {
        require(reviewApproved) { "Explicit review required" }
        val c=dao.candidate(id) ?: error("Unknown candidate")
        require(c.status=="DRAFT")
        val check=validate(id)
        require(check.pass) { "Validation failed: $check" }
        val branch=dao.branch(c.branch) ?: error("Missing branch")
        val next=LineageRules.nextNodeId(dao.allNodes().map { it.id })
        dao.insertNode(Node(next,c.baseId,c.secondParentId,c.payload,sha256(c.payload),System.currentTimeMillis()))
        dao.updateBranch(branch.copy(headId=next))
        dao.updateCandidate(c.copy(status="ACCEPTED"))
        event("NODE_ACCEPTED","$next from ${c.baseId}")
        next
    }
    suspend fun remember(content:String,source:String) = db.withTransaction {
        require(content.isNotBlank() && source.isNotBlank())
        dao.insertMemory(Memory(newId(),content,source));event("MEMORY_ADDED",source)
    }
    suspend fun compare(a:String,b:String):String {
        val left=dao.node(a) ?: error("Unknown first node")
        val right=dao.node(b) ?: error("Unknown second node")
        return "${left.id} (${left.hash.take(10)}) vs ${right.id} (${right.hash.take(10)})\nSame payload: ${left.hash==right.hash}\nFirst:\n${left.payload}\nSecond:\n${right.payload}"
    }
    suspend fun exportJson():String = db.withTransaction {
        val o=JSONObject().put("schema",1)
        fun node(n:Node)=JSONObject().put("id",n.id).put("parentId",n.parentId).put("secondParentId",n.secondParentId).put("payload",n.payload).put("hash",n.hash).put("createdAt",n.createdAt)
        fun branch(b:Branch)=JSONObject().put("name",b.name).put("headId",b.headId)
        fun candidate(c:Candidate)=JSONObject().put("id",c.id).put("branch",c.branch).put("baseId",c.baseId).put("secondParentId",c.secondParentId).put("dimension",c.dimension).put("payload",c.payload).put("status",c.status)
        fun memory(m:Memory)=JSONObject().put("id",m.id).put("content",m.content).put("source",m.source).put("status",m.status)
        fun event(e:AuditEvent)=JSONObject().put("id",e.id).put("kind",e.kind).put("detail",e.detail).put("time",e.time)
        o.put("nodes",JSONArray(dao.allNodes().map(::node)))
        o.put("branches",JSONArray(dao.allBranches().map(::branch)))
        o.put("candidates",JSONArray(dao.allCandidates().map(::candidate)))
        o.put("memories",JSONArray(dao.allMemories().map(::memory)))
        o.put("events",JSONArray(dao.allEvents().map(::event)))
        o.toString(2)
    }
    suspend fun importJson(json:String) {
        val o=JSONObject(json);require(o.getInt("schema")==1)
        fun arr(key:String)=o.getJSONArray(key)
        val nodes=(0 until arr("nodes").length()).map { val n=arr("nodes").getJSONObject(it); Node(n.getString("id"),n.optString("parentId").takeUnless { v->v=="null" || v.isEmpty() },n.optString("secondParentId").takeUnless { v->v=="null" || v.isEmpty() },n.getString("payload"),n.getString("hash"),n.getLong("createdAt")) }
        require(nodes.isNotEmpty() && nodes.map { it.id }.distinct().size==nodes.size)
        require(nodes.all { LineageRules.validNodeId(it.id) }) { "Invalid node ID" }
        require(nodes.count { it.id=="N000" && it.parentId==null && it.secondParentId==null }==1) { "Missing or invalid root" }
        require(nodes.filter { it.id!="N000" }.all { it.parentId!=null }) { "Non-root node missing parent" }
        require(nodes.all { sha256(it.payload)==it.hash }) { "Payload checksum mismatch" }
        val ids=nodes.map { it.id }.toSet()
        require(nodes.all { (it.parentId==null || it.parentId in ids) && (it.secondParentId==null || it.secondParentId in ids) })
        val byId=nodes.associateBy { it.id }
        require(nodes.all { n -> listOfNotNull(n.parentId,n.secondParentId).all { p -> LineageRules.nodeNumber(p) < LineageRules.nodeNumber(n.id) } }) { "Parents must predate descendants" }
        fun acyclic(id:String,stack:Set<String>,seen:MutableSet<String>):Boolean {
            if (id in stack) return false
            if (id in seen) return true
            val n=byId[id] ?: return false
            val next=stack+id
            if (listOfNotNull(n.parentId,n.secondParentId).any { !acyclic(it,next,seen) }) return false
            seen.add(id);return true
        }
        val visited=mutableSetOf<String>();require(nodes.all { acyclic(it.id,emptySet(),visited) })
        val branches=(0 until arr("branches").length()).map { val b=arr("branches").getJSONObject(it);Branch(b.getString("name"),b.getString("headId")) }
        require(branches.isNotEmpty() && branches.map { it.name }.distinct().size==branches.size && branches.all { it.headId in ids && LineageRules.validBranchName(it.name) })
        require(branches.any { it.name=="main" }) { "Missing main branch" }
        val candidates=(0 until arr("candidates").length()).map { val c=arr("candidates").getJSONObject(it);Candidate(c.getString("id"),c.getString("branch"),c.getString("baseId"),c.optString("secondParentId").takeUnless { v->v=="null" || v.isEmpty() },c.getString("dimension"),c.getString("payload"),c.getString("status")) }
        require(candidates.map { it.id }.distinct().size==candidates.size)
        require(candidates.all { it.baseId in ids && branches.any { b->b.name==it.branch } && (it.secondParentId==null || (it.secondParentId in ids && it.secondParentId!=it.baseId)) && it.status in setOf("DRAFT","ACCEPTED","REJECTED") && LineageRules.validDimension(it.dimension) && it.payload.isNotBlank() })
        val memories=(0 until arr("memories").length()).map { val m=arr("memories").getJSONObject(it);Memory(m.getString("id"),m.getString("content"),m.getString("source"),m.getString("status")) }
        val events=(0 until arr("events").length()).map { val e=arr("events").getJSONObject(it);AuditEvent(e.getString("id"),e.getString("kind"),e.getString("detail"),e.getLong("time")) }
        require(memories.map { it.id }.distinct().size==memories.size)
        require(events.map { it.id }.distinct().size==events.size)
        require(candidates.all { it.status != "ACCEPTED" || nodes.any { n -> n.parentId==it.baseId && n.secondParentId==it.secondParentId && n.payload==it.payload } }) { "Accepted candidate missing corresponding node" }
        db.withTransaction {
            dao.clearEvents();dao.clearMemories();dao.clearCandidates();dao.clearBranches();dao.clearNodes()
            // Parent references are plain text; insert order does not affect restoration.
            nodes.forEach { dao.insertNode(it) }
            branches.forEach { dao.insertBranch(it) }
            candidates.forEach { dao.insertCandidate(it) }
            memories.forEach { dao.insertMemory(it) }
            events.forEach { dao.insertEvent(it) }
        }
    }
}
