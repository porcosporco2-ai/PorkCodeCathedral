package com.porkcode.cathedral

/** Pure lineage rules: executable on a JVM without Android or Room. */
object LineageRules {
    private val nodePattern = Regex("N[0-9]{3,}")
    private val branchPattern = Regex("[a-zA-Z0-9_-]{1,40}")
    fun validNodeId(id: String): Boolean = nodePattern.matches(id) && id.removePrefix("N").toIntOrNull() != null
    fun nodeNumber(id: String): Int {
        require(validNodeId(id)) { "Invalid node ID: $id" }
        return id.substring(1).toInt()
    }
    fun nextNodeId(ids: List<String>): String {
        val next = (ids.maxOfOrNull(::nodeNumber) ?: -1).toLong() + 1
        require(next <= Int.MAX_VALUE) { "Node ID space exhausted" }
        return "N" + next.toString().padStart(3, '0')
    }
    fun validBranchName(name: String): Boolean = branchPattern.matches(name)
    fun validDimension(value: String): Boolean = value.isNotBlank() && value.length <= 120
    fun changed(old: String, new: String): Boolean = old != new
}
