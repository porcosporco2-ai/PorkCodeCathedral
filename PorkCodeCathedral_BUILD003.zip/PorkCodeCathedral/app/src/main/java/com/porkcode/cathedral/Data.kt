package com.porkcode.cathedral

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="nodes")
data class Node(@PrimaryKey val id: String, val parentId: String?, val secondParentId: String?, val payload: String, val hash: String, val createdAt: Long)
@Entity(tableName="branches")
data class Branch(@PrimaryKey val name: String, val headId: String)
@Entity(tableName="candidates")
data class Candidate(@PrimaryKey val id: String, val branch: String, val baseId: String, val secondParentId: String?, val dimension: String, val payload: String, val status: String = "DRAFT")
@Entity(tableName="memories")
data class Memory(@PrimaryKey val id: String, val content: String, val source: String, val status: String = "USER_STATED")
@Entity(tableName="events")
data class AuditEvent(@PrimaryKey val id: String, val kind: String, val detail: String, val time: Long)

@Dao
interface CathedralDao {
    @Query("SELECT * FROM nodes ORDER BY createdAt ASC") fun nodes(): Flow<List<Node>>
    @Query("SELECT * FROM branches ORDER BY name") fun branches(): Flow<List<Branch>>
    @Query("SELECT * FROM candidates ORDER BY rowid DESC") fun candidates(): Flow<List<Candidate>>
    @Query("SELECT * FROM memories ORDER BY rowid DESC") fun memories(): Flow<List<Memory>>
    @Query("SELECT * FROM events ORDER BY time") fun events(): Flow<List<AuditEvent>>
    @Query("SELECT * FROM nodes") suspend fun allNodes(): List<Node>
    @Query("SELECT * FROM branches") suspend fun allBranches(): List<Branch>
    @Query("SELECT * FROM candidates") suspend fun allCandidates(): List<Candidate>
    @Query("SELECT * FROM memories") suspend fun allMemories(): List<Memory>
    @Query("SELECT * FROM events") suspend fun allEvents(): List<AuditEvent>
    @Query("SELECT * FROM nodes WHERE id=:id") suspend fun node(id:String): Node?
    @Query("SELECT * FROM branches WHERE name=:name") suspend fun branch(name:String): Branch?
    @Query("SELECT * FROM candidates WHERE id=:id") suspend fun candidate(id:String): Candidate?
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertNode(value:Node)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertBranch(value:Branch)
    @Update suspend fun updateBranch(value:Branch)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertCandidate(value:Candidate)
    @Update suspend fun updateCandidate(value:Candidate)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertMemory(value:Memory)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertEvent(value:AuditEvent)
    @Query("DELETE FROM events") suspend fun clearEvents()
    @Query("DELETE FROM memories") suspend fun clearMemories()
    @Query("DELETE FROM candidates") suspend fun clearCandidates()
    @Query("DELETE FROM branches") suspend fun clearBranches()
    @Query("DELETE FROM nodes") suspend fun clearNodes()
}

@Database(entities=[Node::class,Branch::class,Candidate::class,Memory::class,AuditEvent::class], version=1, exportSchema=false)
abstract class CathedralDatabase: RoomDatabase() { abstract fun dao():CathedralDao }
