package com.porkcode.cathedral

import org.junit.Assert.*
import org.junit.Test

class LineageRulesTest {
    @Test fun numericIdAllocationSkipsGaps() {
        assertEquals("N012", LineageRules.nextNodeId(listOf("N000", "N002", "N011")))
    }
    @Test fun invalidIdsRejected() {
        assertFalse(LineageRules.validNodeId("N0A"))
        assertFalse(LineageRules.validNodeId("N-1"))
        assertTrue(LineageRules.validNodeId("N000"))
    }
    @Test fun dimensionAndBranchChecks() {
        assertFalse(LineageRules.validDimension(" "))
        assertFalse(LineageRules.validBranchName("has spaces"))
        assertTrue(LineageRules.validBranchName("girth_engine"))
    }
    @Test fun noEcho() {
        assertFalse(LineageRules.changed("same", "same"))
        assertTrue(LineageRules.changed("before", "after"))
    }
}
