package com.porkcode.cathedral

import org.junit.Assert.*
import org.junit.Test

class EngineTest {
    @Test fun hashIsStable() { assertEquals(sha256("root"),sha256("root"));assertNotEquals(sha256("root"),sha256("fork")) }
    @Test fun checkRequiresAllPasses() { assertTrue(Check(true,true,true,true,"ok").pass);assertFalse(Check(true,true,false,true,"bad ancestry").pass) }
}
