package com.porkcode.cathedral

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import android.content.Context
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DatabaseTest {
    @Test fun rootForkMutateAcceptAndRestore() = runBlocking {
        val context=ApplicationProvider.getApplicationContext<Context>()
        val db=Room.inMemoryDatabaseBuilder(context,CathedralDatabase::class.java).build()
        try {
            val engine=CathedralEngine(db)
            engine.initialize("original")
            engine.fork("N000","experiment")
            val id=engine.mutate("experiment","text","revised")
            assertTrue(engine.validate(id).pass)
            assertEquals("N001",engine.accept(id,true))
            assertEquals("original",db.dao().node("N000")!!.payload)
            val exported=engine.exportJson()
            engine.importJson(exported)
            assertEquals("revised",db.dao().node("N001")!!.payload)
        } finally { db.close() }
    }
}
